#!/usr/bin/env python3

from brain_games.games.brain_game_progression import play_game_progression


def main():
    play_game_progression()


if __name__ == '__main__':
    main()
