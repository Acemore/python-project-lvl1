#!/usr/bin/env python3

from brain_games.games.brain_game_gcd import play_game_gcd


def main():
    play_game_gcd()


if __name__ == "__main__":
    main()
