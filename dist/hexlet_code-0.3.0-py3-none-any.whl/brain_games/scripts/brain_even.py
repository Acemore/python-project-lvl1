#!/usr/bin/env python3

from brain_games.brain_game_even import play_game_even


def main():
    play_game_even()


if __name__ == '__main__':
    main()
